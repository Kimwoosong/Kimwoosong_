// Coding by Kimwoosong
// 메인페이지(프레임) 용도

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainPage extends JFrame {
    String initialValueDone = "여기에 검색결과가 나옵니다."; // 초기에 생각한 기본문구(검색결과창)
    String initialValueSerch = "여기에 선택한 경로가 나옵니다."; // 초기에 생각한 기본문구(검색창)

    ImageIcon searchButton = new ImageIcon("Images/search.png"); // 검색 이미지 1 (기본)
    ImageIcon searchButtonOn = new ImageIcon("Images/search(2).png"); // 검색 이미지 2 (눌렀을 때)
    ImageIcon folderButton = new ImageIcon("Images/folder.png"); // 폴더 이미지 1 (기본)
    ImageIcon folderButtonOn = new ImageIcon("Images/folder(2).png"); // 폴더 이미지 2 (눌렀을 때)
    ImageIcon filterButton = new ImageIcon("Images/filter.png"); // 필터 이미지 1 (기본)
    ImageIcon filterButtonOn = new ImageIcon("Images/filter(2).png"); // 필터 이미지 2 (눌렀을 때)

    JLabel search = new JLabel("검색"); // 검색창 왼쪽에 검색이라고 알려주는 문구

    JTextField t1 = new JTextField(15); // 폴더 경로가 들어갈 텍스트필드
    JTextArea area = new JTextArea(30, 70); // 검색결과가 나타날 텍스트 에리어

    JTextField f1 = new JTextField(15); // 필터 1 (확장자 검색)
    JTextField f2 = new JTextField(15); // 필터 2 (상세 검색)

    JPanel fPanel = new JPanel(); // 필터 패널

    FileSystemExplorer fileExplorer = new FileSystemExplorer(); // FileSystemExplorer(검색결과 알려주는 함수)를 선언
    FileChooser fileChooser = new FileChooser(); // FileChooser(파일 선택창 함수)를 선언

    String org = ""; // 경로 변수 초기화(파일 경로용)
    String filter = ""; // 필터 받아들이기용 변수 초기화(파일 필터용)

    ActionListener FilterOn = new ActionListener() { // 필터버튼 ON (필터부분을 보이게 해줌)

        public void actionPerformed(ActionEvent e) {
            fPanel.setVisible(true); // 버튼을 누르면 필터검색칸이 보이게 됨
        }
    };

    ActionListener FilterOff = new ActionListener() { // 필터버튼 Off (필터부분을 숨기게 해줌)

        public void actionPerformed(ActionEvent e) {
            fPanel.setVisible(false); // 버튼을 누르면 필터검색칸이 숨겨지게 됨
        }
    };

    ActionListener FilterSearch01 = new ActionListener() { // 필터버튼 on 되어있을때 사용가능한 확장자 필터서치

        public void actionPerformed(ActionEvent e) {
            area.setText(""); // 텍스트 에리어를 초기화시킴(검색 버튼 누를때마다 데이터가 쌓이지 않음)
            org = t1.getText(); // 텍스트필드(검색창)의 텍스트를 읽어서 org 변수에 저장
            filter = f1.getText(); // 확장자 필터 텍스트를 읽어들임
            area.setText(fileExplorer.filterFile01(org, filter)); // 경로와 필터텍스트를 파일검색클래스로 넘김
        }
    };

    ActionListener FilterSearch02 = new ActionListener() { // 필터버튼 on 되어있을때 사용가능한 상세검색 필터서치

        public void actionPerformed(ActionEvent e) {
            area.setText(""); // 텍스트 에리어를 초기화시킴(검색 버튼 누를때마다 데이터가 쌓이지 않음)
            org = t1.getText(); // 텍스트필드(검색창)의 텍스트를 읽어서 org 변수에 저장
            filter = f2.getText(); // 상세검색 필터 텍스트를 읽어들임
            area.setText(fileExplorer.filterFile02(org, filter)); // 경로와 필터텍스트를 파일검색클래스로 넘김
        }
    };

    ActionListener SearchIn = new ActionListener() {

        public void actionPerformed(ActionEvent e) {
            area.setText(""); // 텍스트 에리어를 초기화시킴(검색 버튼 누를때마다 데이터가 쌓이지 않음)
            org = t1.getText(); // 텍스트필드(검색창)의 텍스트를 읽어서 org 변수에 저장
            area.setText(fileExplorer.printFileSystem(org));// FileSystemExplorer 클래스에 변수 넘김(리턴값으로 결과값을 반환함)
        }
    };

    ActionListener FolderIn = new ActionListener() { // 폴더 선택 액션

        public void actionPerformed(ActionEvent e) {
            org = fileChooser.jFileChooserUtil(); // 폴더 선택기능 함수
            t1.setText(org);// 텍스트필드에 org(폴더의 경로)를 넣음
        }
    };

    MainPage() { // 메인페이지 함수
        setTitle("메인페이지"); // 프레임의 이름 추가
        setLayout(new BorderLayout()); // 레이아웃을 동서남북으로 나누기 위해 사용

        showPanel(); // 패널을 불러오는 함수

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 이걸 호출해야 x클릭시 프로그램 정상종료
        setSize(820, 700);
        setVisible(true);
    }

    void showPanel() {
        JPanel p1 = new JPanel();

        // 검색 버튼 생성 및 옵션 추가
        JButton search = new JButton(searchButton);
        search.setRolloverIcon(searchButtonOn);
        search.setBorderPainted(false);
        search.setPreferredSize(new Dimension(20, 20));
        search.addActionListener(SearchIn);

        // 폴더 선택 버튼 생성 및 옵션 추가
        JButton folder = new JButton(folderButton);
        folder.setRolloverIcon(folderButtonOn);
        folder.setBorderPainted(false);
        folder.setPreferredSize(new Dimension(20, 20));
        folder.addActionListener(FolderIn);

        // 필터검색칸 on, off 버튼
        JButton filter = new JButton(filterButton); // 필터 on 버튼 생성
        filter.setRolloverIcon(filterButtonOn);
        filter.setBorderPainted(false);
        filter.setPreferredSize(new Dimension(20, 20));
        filter.addActionListener(FilterOn); // 필터 on 액션 발생

        JButton fOffButton = new JButton(filterButton); // 필터 off 버튼 생성
        fOffButton.setRolloverIcon(filterButtonOn);
        fOffButton.setBorderPainted(false);
        fOffButton.setPreferredSize(new Dimension(20, 20));
        fOffButton.addActionListener(FilterOff); // 필터 off 액션 발생

        JButton fSearchButton01 = new JButton("확장자 검색"); // 필터 검색 버튼
        fSearchButton01.addActionListener(FilterSearch01); // 필터 검색 액션 발생

        JButton fSearchButton02 = new JButton("파일명 검색"); // 필터 검색 버튼
        fSearchButton02.addActionListener(FilterSearch02); // 필터 검색 액션 발생

        fPanel.add(f1);
        fPanel.add(fSearchButton01);
        fPanel.add(f2);
        fPanel.add(fSearchButton02);
        fPanel.add(fOffButton);

        fPanel.setVisible(false);

        t1.setText(initialValueSerch);
        t1.setEditable(false);

        p1.add(folder); // 폴더선택 버튼(아이콘)
        p1.add(t1); // 검색용 텍스트필드
        p1.add(search); // 검색시작 버튼(아이콘)
        p1.add(filter);

        add(p1, BorderLayout.NORTH);
        // 필터검색말고 이미 검색된 결과 중 찾기기능 넣어야됨
        add(fPanel, BorderLayout.SOUTH);

        JPanel p2 = new JPanel();
        JScrollPane scrollPane = new JScrollPane(area);
        area.setEditable(false);
        area.setText(initialValueDone);
        p2.add(scrollPane);
        add(p2, BorderLayout.CENTER);

    }
}
