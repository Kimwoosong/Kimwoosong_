public class test {
    public static void main(String[] args) {
        int i = 0;
        while (true) {
            ++i;
            if (i == 4) {
                break;
            }

        }
        System.out.printf("i = %d", i);
    }
}
