// Coding by Kimwoosong
// 파일 검색기능용도(예제 참고함)

import java.io.*;

public class FileSystemExplorer {
    public String printFileSystem(String path) { // 기본검색 필터
        // 1. 파일 객체 생성 (path 정보를 가지는 파일 만듬)
        File directory = new File(path); // 현재 경로를 파일 객체로 생성
        File file = null;
        // 1-1. directory 안의 내용을 탐색한다.
        String[] contents = directory.list(); // contents 리스트에 directory 리스트를 넣음
        String result = ""; // 결과값 초기화
        try {
            for (String content : contents) {
                file = new File(directory.getAbsolutePath() + File.separator + content);

                // 파일의 용량을 체크하기 위한 변수 호출
                double bytes = file.length();
                double kiloByte = bytes / 1024;
                double megaByte = kiloByte / 1024;
                double gigaByte = megaByte / 1024;

                // 현재 경로에 파일 구분자(File.separator)와 파일명(content) 추가해 파일 객체 생성
                if (file.isDirectory()) {
                    // 2-1. 폴더일 경우 폴더 내부 탐색한다. (재귀함수 호출 필요)
                    // printFileSystem(file.getAbsolutePath());
                    result += printFileSystem(file.getAbsolutePath()) + "\n";
                } else {
                    // 2-2. 파일일 경우 파일의 경로를 출력한다.
                    // System.out.println(file.getAbsolutePath()); // 출력 확인용
                    // 파일 크기에 따라 표기방식 분류
                    if (megaByte > 1024) {
                        result += file.getAbsolutePath() + "\n용량 : " + Math.round(gigaByte) + "Gb\n";
                    } else if (kiloByte > 1024) {
                        result += file.getAbsolutePath() + "\n용량 : " + Math.round(megaByte) + "Mb\n";
                    } else if (bytes > 1024) {
                        result += file.getAbsolutePath() + "\n용량 : " + Math.round(kiloByte) + "Kb\n";
                    } else {
                        result += file.getAbsolutePath() + "\n용량 : " + Math.round(bytes) + "Byte\n";
                    }
                    // 결과값을 result 변수에 한줄씩 띄워서 저장
                }
            }
            return result; // 함수를 불러오면 결과값(파일 경로 출력결과)을 반환
        } catch (Exception ex) {
            result = "검색경로를 찾을 수 없습니다.";
            return result;
        }
    }

    public String filterFile01(String path, String filter) { // 확장자 필터
        // 1. 파일 객체 생성 (path 정보를 가지는 파일 만듬)
        File directory = new File(path); // 현재 경로를 파일 객체로 생성
        File file = null;
        // 1-1. directory 안의 내용을 탐색한다.
        String[] contents = directory.list(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) { // 파일의 필터링을 위해 boolean으로 호출 (디렉토리 경로, 파일명을 받음)
                return name.endsWith("." + filter); // 확장자 필터(필터링된 값들만 true로 넣어짐)
            }
        });

        String result = "";

        try {
            for (String content : contents) {
                file = new File(directory.getAbsolutePath() + File.separator + content);

                // 파일의 용량을 체크하기 위한 변수 호출
                double bytes = file.length();
                double kiloByte = bytes / 1024;
                double megaByte = kiloByte / 1024;
                double gigaByte = megaByte / 1024;

                // 현재 경로에 파일 구분자(File.separator)와 파일명(content) 추가해 파일 객체 생성
                if (file.isDirectory()) {
                    // 2-1. 폴더일 경우 폴더 내부 탐색한다. (재귀함수 호출 필요)
                    // printFileSystem(file.getAbsolutePath());
                    result += printFileSystem(file.getAbsolutePath()) + "\n"; // 재귀함수 호출과 띄워쓰기 용도
                } else {
                    // 2-2. 파일일 경우 파일의 경로를 출력한다.
                    // System.out.println(file.getAbsolutePath()); // 출력 확인용
                    // 파일 크기에 따라 표기방식 분류
                    if (megaByte > 1024) {
                        result += file.getAbsolutePath() + "\n용량 : " + Math.round(gigaByte) + "Gb\n";
                    } else if (kiloByte > 1024) {
                        result += file.getAbsolutePath() + "\n용량 : " + Math.round(megaByte) + "Mb\n";
                    } else if (bytes > 1024) {
                        result += file.getAbsolutePath() + "\n용량 : " + Math.round(kiloByte) + "Kb\n";
                    } else {
                        result += file.getAbsolutePath() + "\n용량 : " + Math.round(bytes) + "Byte\n";
                    }
                    // 결과값을 result 변수에 한줄씩 띄워서 저장
                }
            }
            return result; // 함수를 불러오면 결과값(파일 경로 출력결과)을 반환
        } catch (Exception ex) {
            result = "검색경로를 찾을 수 없습니다.";
            return result;
        }
    }

    public String filterFile02(String path, String filter) {// 상세 검색 필터
        // 1. 파일 객체 생성 (path 정보를 가지는 파일 만듬)
        File directory = new File(path); // 현재 경로를 파일 객체로 생성
        File file = null;
        // 1-1. directory 안의 내용을 탐색한다.
        String[] contents = directory.list(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return name.startsWith(filter);
            }
        });

        String result = "";

        try {
            for (String content : contents) {
                file = new File(directory.getAbsolutePath() + File.separator + content);

                // 파일의 용량을 체크하기 위한 변수 호출
                double bytes = file.length();
                double kiloByte = bytes / 1024;
                double megaByte = kiloByte / 1024;
                double gigaByte = megaByte / 1024;

                // 현재 경로에 파일 구분자(File.separator)와 파일명(content) 추가해 파일 객체 생성
                if (file.isDirectory()) {
                    // 2-1. 폴더일 경우 폴더 내부 탐색한다. (재귀함수 호출 필요)
                    // printFileSystem(file.getAbsolutePath());
                    result += printFileSystem(file.getAbsolutePath()) + "\n";
                } else {
                    // 2-2. 파일일 경우 파일의 경로를 출력한다.
                    // System.out.println(file.getAbsolutePath()); // 출력 확인용
                    // 파일 크기에 따라 표기방식 분류
                    if (megaByte > 1024) {
                        result += file.getAbsolutePath() + "\n용량 : " + Math.round(gigaByte) + "Gb\n";
                    } else if (kiloByte > 1024) {
                        result += file.getAbsolutePath() + "\n용량 : " + Math.round(megaByte) + "Mb\n";
                    } else if (bytes > 1024) {
                        result += file.getAbsolutePath() + "\n용량 : " + Math.round(kiloByte) + "Kb\n";
                    } else {
                        result += file.getAbsolutePath() + "\n용량 : " + Math.round(bytes) + "Byte\n";
                    }
                    // 결과값을 result 변수에 한줄씩 띄워서 저장
                }
            }
            return result; // 함수를 불러오면 결과값(파일 경로 출력결과)을 반환
        } catch (Exception ex) {
            result = "검색경로를 찾을 수 없습니다.";
            return result;
        }
    }
}
