// Coding by Kimwoosong
// 실행 용도
public class RunTest {
    public static void main(String[] args) {
        new MainPage();
    }
}
