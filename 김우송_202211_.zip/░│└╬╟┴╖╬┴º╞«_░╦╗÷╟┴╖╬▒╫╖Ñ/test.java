import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;

import java.io.File;

public class test {

    public static String jFileChooserUtil() {

        String folderPath = "";

        JFileChooser chooser = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory()); // 디렉토리 설정
        chooser.setCurrentDirectory(new File("/")); // 현재 사용 디렉토리를 지정
        chooser.setAcceptAllFileFilterUsed(true); // Fileter 모든 파일 적용
        chooser.setDialogTitle("타이틀"); // 창의 제목
        chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES); // 파일 선택 모드

        FileNameExtensionFilter filter = new FileNameExtensionFilter("Binary File", "cd11"); // filter 확장자 추가
        chooser.setFileFilter(filter); // 파일 필터를 추가

        int returnVal = chooser.showOpenDialog(null); // 열기용 창 오픈

        if (returnVal == JFileChooser.APPROVE_OPTION) { // 열기를 클릭
            folderPath = chooser.getSelectedFile().toString();
        } else if (returnVal == JFileChooser.CANCEL_OPTION) { // 취소를 클릭
            System.out.println("cancel");
            folderPath = "";
        }

        return folderPath;

    }

    public void printFileSystem(String path) {
        // 1. 파일 객체 생성 (path 정보를 가지는 파일 만듬)
        File directory = new File(path); // 현재 경로를 파일 객체로 생성

        // 1-1. directory 안의 내용을 탐색한다.

        String[] contents = directory.list();
        File file = null;
        // 2. directory 객체의 내용이 폴더인지 파일인지 구분한다.

        for (String content : contents) {
            file = new File(directory.getAbsolutePath() + File.separator + content);
            // 현재 경로에 파일 구분자(File.separator)와 파일명(content) 추가해 파일 객체 생성
            if (file.isDirectory()) {
                // 2-1. 폴더일 경우 폴더 내부 탐색한다. (재귀함수 호출 필요)
                printFileSystem(file.getAbsolutePath());
            } else {
                // 2-2. 파일일 경우 파일의 경로를 출력한다.
                System.out.println(file.getAbsolutePath());
            }
        }
    }

    public static void main(String[] args) {
        FileSystemExplorer fileExplorer = new FileSystemExplorer();
        fileExplorer.printFileSystem("D:\\Temp");
    }
}
